package javaff.threading;
public enum SearchType {
    EHC,
    SA,
    IDTM,
    BFS;
    
    public static int COUNT = SearchType.values().length;
}
